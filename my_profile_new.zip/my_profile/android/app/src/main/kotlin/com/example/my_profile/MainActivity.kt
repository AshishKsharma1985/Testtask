package com.example.my_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
