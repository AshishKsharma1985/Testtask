class Constant{

  static const String imageUserPath = "assets/images/ic_user.png";

}